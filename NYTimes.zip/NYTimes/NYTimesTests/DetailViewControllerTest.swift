//
//  DetailViewControllerTest.swift
//  NYTimesTests
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import XCTest
@testable import NYTimes

class DetailViewControllerTest: XCTestCase {

    var detailViewController:DetailViewController!
    
    var metaData:MediaMetadata {
        get {
            return MediaMetadata(url: "https:static01.nyt.comimages20181015us15MICHAEL-HOUSE-115MICHAEL-HOUSE-1-square320.jpg", format: "square320", height: 320, width: 320)
        }
    }
    
    var media:Media {
        get {
            return Media(type: "image", subtype: "photo", caption: "The elevated house", copyright: "copyright", approvedForSyndication: 1, mediaMetadata: [self.metaData])
        }
    }
    
    var mostViewed:MostViewedResults {
        get {
            return MostViewedResults(url: "https:www.nytimes.com20181014ushurricane-michael-florida-mexico-beach-house.html", adxKeywords: "adxKeywords", column: "column", section: "section", byline: "byline", type: "type", title: "title", abstract: "abstract", publishedDate: "publishedDate", source: "source", id: 11, assetId: 22, views: 1, media: [self.media])
        }
    }
    
    override func setUp() {
        detailViewController = UIStoryboard().details
        detailViewController.detailItem = NYTimeViewModel(data: mostViewed)
        detailViewController.loadViewIfNeeded()
    }
    
    override func tearDown() {
        detailViewController = nil
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    
    func testViewDidLoad(){
        detailViewController.viewDidLoad()
        XCTAssert(self.detailViewController.title != nil, "Controller title is not set")
        detailViewController.viewWillAppear(true)
    }
    


    func testHasATableView() {
        XCTAssertNotNil(detailViewController.tableView)
    }
    
    func testTableViewHasDelegate() {
        XCTAssertNotNil(detailViewController.tableView.delegate)
    }
    
    func testTableViewConfromsToTableViewDelegateProtocol() {
        XCTAssertTrue(detailViewController.conforms(to: UITableViewDelegate.self))
    }
    
    func testTableViewHasDataSource() {
        XCTAssertNotNil(detailViewController.tableView.dataSource)
    }
    
    func testArticleButtonTapped(){
        self.detailViewController.tapOnLinktoArticleButton(UIButton())
    }
    
    func testTableViewConformsToTableViewDataSourceProtocol() {
        XCTAssertTrue(detailViewController.conforms(to: UITableViewDataSource.self))
        XCTAssertTrue(detailViewController.responds(to: #selector(detailViewController.tableView(_:numberOfRowsInSection:))))
        XCTAssertTrue(detailViewController.responds(to: #selector(detailViewController.tableView(_:cellForRowAt:))))
    }
    
    func testTableViewCellHasReuseIdentifier() {
        let cell = detailViewController.tableView(detailViewController.tableView, cellForRowAt: IndexPath(row: 0, section: 0)) as? DetailSummaryTableViewCell
        let actualReuseIdentifer = cell?.reuseIdentifier
        let expectedReuseIdentifier = "Cell"
        XCTAssertEqual(actualReuseIdentifer, expectedReuseIdentifier)
    }

    func testTableView(){
        self.detailViewController.detailItem = NYTimeViewModel(data: mostViewed)
        detailViewController.loadViewIfNeeded()
        self.detailViewController.tableView.reloadData()
    }
    
   
    
}
    

