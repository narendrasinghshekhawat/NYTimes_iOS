//
//  MasterViewControllerTest.swift
//  NYTimesTests
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import XCTest
@testable import NYTimes

class MasterViewControllerTest: XCTestCase {
    
    var masterViewController:MasterViewController!
    var service = Services()
    
    var metaData:MediaMetadata {
        get {
            return MediaMetadata(url: "https:static01.nyt.comimages20181015us15MICHAEL-HOUSE-115MICHAEL-HOUSE-1-square320.jpg", format: "square320", height: 320, width: 320)
        }
    }
    
    var media:Media {
        get {
            return Media(type: "image", subtype: "photo", caption: "The elevated house", copyright: "copyright", approvedForSyndication: 1, mediaMetadata: [self.metaData])
        }
    }
    
    var mostViewed:MostViewedResults {
        get {
            return MostViewedResults(url: "https:www.nytimes.com20181014ushurricane-michael-florida-mexico-beach-house.html", adxKeywords: "adxKeywords", column: "column", section: "section", byline: "byline", type: "type", title: "title", abstract: "abstract", publishedDate: "publishedDate", source: "source", id: 11, assetId: 22, views: 1, media: [self.media])
        }
    }
    
    override func setUp() {
        masterViewController = UIStoryboard().master
        self.masterViewController.loadLatestItems(selectedType: .Day)
    }
    
    override func tearDown() {
        masterViewController = nil
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testViewDidLoad(){
        masterViewController.viewDidLoad()
        XCTAssert(self.masterViewController.title != nil, "Controller tittle is not set")
        XCTAssert(!(self.masterViewController.detailViewController != nil) , "Error")
    }
    
    func testService(){
        let expectation = XCTestExpectation(description: "Download apple.com home page")

        self.service.fetchData(url: Constants.ServiceURL.urlRequest(for: .Day)) { (data, error) in
            XCTAssertNotNil(data, "data not found")
            expectation.fulfill()
    }
        self.masterViewController.tableView.reloadData()
    }
    
    func testNegetiveLoadLatestItems(){
        let expectation = XCTestExpectation(description: "Download apple.com home page")
        
        self.service.fetchData(url: Constants.ServiceURL.urlRequest(for: .Day)) { (data, error) in
            XCTAssertNotNil(data, "data not found")
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 8.0)
    }
    
    func testButtonActions(){
         self.masterViewController.didTapLeftButtonItem(UIButton())
        self.masterViewController.didTapMoreButtonItem(UIButton())
        self.masterViewController.didTapSearchButtonItem(UIButton())
    }
    
    func testButtonNegativeTest(){
        self.masterViewController.searchMode = true
        self.masterViewController.didTapSearchButtonItem(UIButton())
    }
    
    func testFilters(){
        self.masterViewController.showTimePeriodFilters()
    }
    
    func testTableViewDatasource(){
       self.masterViewController.tableView = UITableView()
       self.masterViewController.tableView.register(UITableViewCell.self,
                           forCellReuseIdentifier: "Cell")
        
        self.masterViewController.tableView.dataSource?.tableView(self.masterViewController.tableView, numberOfRowsInSection: 3)
       let _ = self.masterViewController.tableView.dataSource?.tableView(self.masterViewController.tableView, numberOfRowsInSection: 3)
    }
    
    func testSegue(){
        self.masterViewController.timeViewModel = [NYTimeViewModel(data: mostViewed)]

        self.masterViewController.tableView = UITableView()
        masterViewController.tableView.selectRow(at: IndexPath(row: 0, section: 0), animated: true, scrollPosition: .none)
        let details = UIStoryboard().detailsNav
        let seque = UIStoryboardSegue(identifier: "showDetail", source: masterViewController, destination: details)
        masterViewController.prepare(for: seque, sender: nil)
    }
    
}

