//
//  NYTimesTests.swift
//  NYTimesTests
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import XCTest
@testable import NYTimes

class NYTimesTests: XCTestCase {

    var metaData:MediaMetadata {
        get {
            return MediaMetadata(url: "https:static01.nyt.comimages20181015us15MICHAEL-HOUSE-115MICHAEL-HOUSE-1-square320.jpg", format: "square320", height: 320, width: 320)
        }
    }

    var media:Media {
        get {
            return Media(type: "image", subtype: "photo", caption: "The elevated house", copyright: "copyright", approvedForSyndication: 1, mediaMetadata: [self.metaData])
        }
    }
    
    var mostViewed:MostViewedResults {
        get {
            return MostViewedResults(url: "https:www.nytimes.com20181014ushurricane-michael-florida-mexico-beach-house.html", adxKeywords: "adxKeywords", column: "column", section: "section", byline: "byline", type: "type", title: "title", abstract: "abstract", publishedDate: "publishedDate", source: "source", id: 11, assetId: 22, views: 1, media: [self.media])
        }
    }
    
    var timeModel:NYTimeModel {
        get {
            return NYTimeModel(status: "status", copyright: "copyright", numResults: 1, results: [self.mostViewed])
        }
    }
    
    
    var metaDataWithNil:MediaMetadata {
        get { return MediaMetadata(url: nil, format: nil, height: 320, width: 320)}
    }

    var mediaWithNil:Media {
        get { return Media(type: nil, subtype: nil, caption: nil, copyright: nil, approvedForSyndication: nil, mediaMetadata: [self.metaDataWithNil])}
    }
    
    
    var mostViewedWithNil:MostViewedResults {
        get { return MostViewedResults(url: nil, adxKeywords: nil, column: nil, section: nil, byline: nil, type: nil, title: nil, abstract: nil, publishedDate: nil, source: nil, id: 11, assetId: 22, views: 1, media: [self.mediaWithNil]) }
    }
    

    
    override func setUp() {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }

    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testNewsViewModel() {
        let mostViewedNews = timeModel.results
        let newsViewModel = NYTimeViewModel(data: mostViewed)

        // what is it that we want to test?
        XCTAssertEqual(newsViewModel.title, mostViewedNews[0].title)
        XCTAssertEqual(newsViewModel.section, mostViewedNews[0].section)
        XCTAssertEqual(newsViewModel.abstract, mostViewedNews[0].abstract)
        XCTAssertEqual(newsViewModel.url, mostViewedNews[0].url)
        XCTAssertEqual(newsViewModel.date, mostViewedNews[0].publishedDate)
    }
    
    func testNegetiveNewsViewModel() {
        let newsViewModel = NYTimeViewModel(data: self.mostViewedWithNil)

        // what is it that we want to test?
        XCTAssertEqual(newsViewModel.title, "")
        XCTAssertEqual(newsViewModel.section, "")
        XCTAssertEqual(newsViewModel.abstract, "")
        XCTAssertEqual(newsViewModel.url, "")
        XCTAssertEqual(newsViewModel.date, "")
    }

}
