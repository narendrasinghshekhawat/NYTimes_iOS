//
//  Constants.swift
//  NYTimes
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import Foundation
import UIKit

enum URLType: String {
    case Day = "1"
    case Week = "7"
    case Month = "30"
    
    func getDisplayName() -> String {
        switch self {
        case .Day:
            return "Day"
        case .Week:
            return "Week"
        case .Month:
            return "Month"
        }
    }
    
    func url()->String{
        return Constants.ServiceURL.urlRequest(for: self)
    }
    
}

extension URLType: CaseIterable {}

struct Constants {
        
    enum AlertString: String {
            case somethingWrong = "Something went wrong please try again later"
            case specificPeriod = "See items for specific period"
    }
    
    struct ServiceURL {
        fileprivate static let baseURLString = "http://api.nytimes.com/svc/mostpopular/v2/mostviewed/all-sections/"
        fileprivate static let keyString = ".json?api-key=K81oOyCveDxRRGqSiEAmoTRIgCmHllIj&offset=0"

        static func urlRequest(for type: URLType) -> String {
            
            let urlString: String
            switch type {
            case .Day:
                urlString = ServiceURL.baseURLString + "1" + ServiceURL.keyString
            case .Week:
                urlString = ServiceURL.baseURLString + "7"  + ServiceURL.keyString
            case .Month:
                urlString = ServiceURL.baseURLString + "30"  + ServiceURL.keyString
            }
            return urlString
        }
    }
}
