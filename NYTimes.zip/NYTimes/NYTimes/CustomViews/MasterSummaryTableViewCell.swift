//
//  MasterSummaryTableViewCell.swift
//  NYTimes
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import UIKit

class MasterSummaryTableViewCell: UITableViewCell {

    @IBOutlet weak var thumbnailView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var byLineLabel: UILabel!
    @IBOutlet weak var publishDateLabel: UILabel!
    
    var dataViewModel:NYTimeViewModel? {
        didSet {
            dataRepresentationInView()
        }
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        DispatchQueue.main.async {
            self.thumbnailView?.makeRounded()
          //  self.thumbnailView.layer.masksToBounds = true
        }
        // Initialization code
    }
    
    func dataRepresentationInView(){
        guard let dataViewModel = dataViewModel else {
            return
        }
        self.titleLabel.text = dataViewModel.title
        self.publishDateLabel.text = "🗓 " + dataViewModel.date
        self.byLineLabel.text = dataViewModel.byline
        self.thumbnailView.loadImage(urlString: dataViewModel.thumbnailImageStr)
    }

}
extension UIImageView {
    func makeRounded() {
        let radius = self.frame.width/2.0
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
}
