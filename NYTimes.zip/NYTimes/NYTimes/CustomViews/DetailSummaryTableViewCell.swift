//
//  DetailSummaryTableViewCell.swift
//  NYTimes
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import UIKit

class DetailSummaryTableViewCell: UITableViewCell {

    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var newsImageView: UIImageView!
    
    var dataViewModel:NYTimeViewModel?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func dataRepresentationInView(){
        guard let dataViewModel = dataViewModel else {
            return
        }
        self.titleLabel.text = dataViewModel.title
        self.dateLabel.text = "🗓 " + dataViewModel.date
        self.descriptionLabel.text = dataViewModel.abstract
        self.categoryLabel.text = dataViewModel.section
        self.newsImageView.loadImage(urlString: dataViewModel.largeImageStr)
    }


}
