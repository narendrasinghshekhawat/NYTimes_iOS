//
//  MasterViewController.swift
//  NYTimes
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import UIKit

class MasterViewController: UITableViewController, UISearchBarDelegate {

    // MARK: - Variables
    var timeViewModel = [NYTimeViewModel]()
    // MARK: - Properties
    var detailViewController: DetailViewController? = nil
    let searchBar = UISearchBar()
    var searchMode = false
    var defaultTimePeriod:String!

    
    //MARK:- Manage View
    override func viewDidLoad() {
        super.viewDidLoad()
        loadLatestItems(selectedType: .Week)
        configureSplitController()
    }
    
    private func configureSplitController(){
        if let split = splitViewController {
            let controllers = split.viewControllers
            detailViewController = (controllers[controllers.count-1] as! UINavigationController).topViewController as? DetailViewController
        }
        configureSearchBar()
    }
    
    private func configureSearchBar(){
        searchBar.customSearchBar()
        searchBar.showsCancelButton = true
        searchBar.returnKeyType = UIReturnKeyType.done
        searchBar.delegate = self
    }

    override func viewWillAppear(_ animated: Bool) {
        clearsSelectionOnViewWillAppear = splitViewController!.isCollapsed
        super.viewWillAppear(animated)
    }
    
    //MARK:- Api Call
     func loadLatestItems(selectedType: URLType) {
        self.timeViewModel.removeAll()
        Services.shared.fetchData(url: selectedType.url(), completion: { (timesData, err ) in
            if let _ = err {
                self.showAlert(title: "", message: Constants.AlertString.somethingWrong.rawValue, delegate: self, cancelButtonTitle: "OK")
                return
            }
            self.timeViewModel = (timesData?.results.map({return NYTimeViewModel(data: $0)}))!
            self.tableView.reloadData()
        })
    }
    
    
    // MARK: - Button Actions
    @IBAction func didTapLeftButtonItem(_ sender: Any) {
        print("didTapLeftButtonItem")
    }
    
    @IBAction func didTapMoreButtonItem(_ sender: Any) {
        self.showTimePeriodFilters()
    }
    
    @IBAction func didTapSearchButtonItem(_ sender: Any) {
        
        if self.searchMode == true {
            searchBarCancelButtonClicked(self.searchBar)
            return
        }
        //self.filteredSearchResultList = self.mostViewedItemsList
        self.searchMode = true
        self.tableView.tableHeaderView = searchBar
        searchBar.sizeToFit()
        searchBar.becomeFirstResponder()
    }
    
    // MARK: - Search Bar
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        self.searchMode = false
        searchBar.resignFirstResponder()
        self.tableView.tableHeaderView = nil
        self.tableView.reloadData()
    }

    //Mark:- Custom functions
    func showTimePeriodFilters() {
        
        let alert = UIAlertController(title: Constants.AlertString.specificPeriod.rawValue, message: nil, preferredStyle: UIAlertController.Style.actionSheet)
        
        URLType.allCases.forEach { (section) in
            let timePeriodAction = UIAlertAction(title: self.getDisplayNameForTimePeriod(timePeriod: section.getDisplayName()),
                                                 style: .default, handler: { action in
                                                    self.defaultTimePeriod = section.getDisplayName()
                                                    print(self.defaultTimePeriod!)
                                                    self.loadLatestItems(selectedType: section)
            })
            alert.addAction(timePeriodAction)
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alert.addAction(cancelAction)
        self.present(alert, animated: true, completion: nil)
    }
    
    private func getDisplayNameForTimePeriod(timePeriod: String) -> String {
        var displayName = timePeriod
        if self.defaultTimePeriod == timePeriod {
            displayName = "✓ " + displayName
        }
        return displayName
    }
    
    
}


extension MasterViewController{
    
    // MARK: - Table View
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return objects.count
        return timeViewModel.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! MasterSummaryTableViewCell
            cell.dataViewModel = timeViewModel[indexPath.row]
        return cell
    }
    
    
    // MARK: - Segues
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            if let indexPath = tableView.indexPathForSelectedRow {
                let object = timeViewModel[indexPath.row]
                let controller = (segue.destination as! UINavigationController).topViewController as! DetailViewController
                controller.detailItem = object
                controller.navigationItem.leftBarButtonItem = splitViewController?.displayModeButtonItem
                controller.navigationItem.leftItemsSupplementBackButton = true
            }
        }
    }
}

