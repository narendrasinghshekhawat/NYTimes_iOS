//
//  DetailViewController.swift
//  NYTimes
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var tableView: UITableView!
    
    //MARK:- Properties
    var detailItem: NYTimeViewModel?
    
    //MARK:- Manage View
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.tableView.reloadData()
    }
    
    // MARK: - Button Actions
    @IBAction func tapOnLinktoArticleButton(_ sender: UIButton) {
        if let url = URL(string: detailItem?.url ?? "") {
            UIApplication.shared.open(url, options: [:])
        }
    }
}


extension DetailViewController:UITableViewDelegate,UITableViewDataSource{
    
    // MARK: - Table View
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! DetailSummaryTableViewCell
        if let detailItem = detailItem  {
            cell.dataViewModel = detailItem
            cell.dataRepresentationInView()
        }
        return cell
    }
}



