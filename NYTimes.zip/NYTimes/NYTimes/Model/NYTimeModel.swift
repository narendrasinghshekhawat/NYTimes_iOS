//
//  NYTimeModel.swift
//  NYTimes
//
//  Created by Narendra on 28/03/19.
//  Copyright © 2019 Narendra. All rights reserved.
//

import Foundation


struct NYTimeModel: Decodable {
    var status:String?
    var copyright:String?
    var numResults:Int?
    var results:[MostViewedResults]
}

struct MostViewedResults: Decodable {
    var url:String?
    var adxKeywords:String?
    var column:String?
    var section:String?
    var byline:String?
    var type:String??
    var title:String?
    var abstract:String?
    var publishedDate:String?
    var source:String?
    var id:Int?
    var assetId:Int?
    var views:Int?


    var media:[Media]
}

struct Media: Decodable {
    var type:String?
    var subtype:String?
    var caption:String?
    var copyright:String?
    var approvedForSyndication:Int?
    var mediaMetadata:[MediaMetadata]
    
    private enum CodingKeys: String, CodingKey {
        case mediaMetadata = "media-metadata"
        case type, subtype, caption, copyright, approvedForSyndication
    }

}

struct MediaMetadata: Decodable {
    public var url:String?
    public var format:String?
    public var height:Int?
    public var width:Int?
}
